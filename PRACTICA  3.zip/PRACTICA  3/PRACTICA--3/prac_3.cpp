#include "prac_3.h"

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <bitset>
#include <cmath>

using namespace std;

string reverse(string s)
{
    string rev;
    for (int i = s.size() - 1; i >= 0; i--) {
        rev = rev.append(1, s[i]);
    };

    return rev;
}

string binario(int X,string str){
    int Y;
    string r;
    string H="";
    string stri;
    for (int i=0;i<X;i++){
        Y = str[i];
        while (Y != 0){
            if (Y%2==0){
                r += "0";
            }
            if (Y%2==1){
                r += "1";
            }
            //r += ( Y % 2 == 0 ? "0" : "1" );
            Y /= 2;
        }
        r = reverse(r);
        bitset<8> bs1(r);
        stri = bs1.to_string();
        H += stri;
        r = "";
    }
    return H;
}

char guardar(char texto[])
{

FILE *archivo; // FILE se escribe en mayuscula

archivo = fopen( "documento.txt", "w"); // En el segundo parametro se escribe la forma en que sera abierto "w"

fprintf(archivo,texto);

return 0;

}

string decimal(string binario){
    string N;
    int K=binario.size();
    int F=K/8;
    char decimales[F]="";
    int decimal=0;
    int D;
    int U=0;
    char guar[K];

    for (int i=0;i<K;i++){
        if (binario[i]==48){
            guar[i]=48;
        }
        else {
            guar[i]=49;
        }
    }

    for (int i=0;i<K;i=i+8){
        N= binario.substr(i,8);
        for (int j=0;j<8;j++){
            if (N[j]==49){
                D = 1+ pow(2,j);
                decimal=decimal+D;
            }
        }
        decimales[U]=decimal;
        decimal=0;
        U++;
    }

    for (int i=0;i<F;i++){
        cout<<decimales[i];

    }
    cout<<"\n";

    FILE *archivo;
    archivo = fopen( "documento.txt", "w");
    fprintf(archivo,guar);

    cout<<"\n";

    return 0;
}

string camN(string Z){
    for (int j=0;j<4;j++){
        if (Z[j]==48){
            Z[j]=49;
        }
        else {
            Z[j]=48;
        }
    }
    return Z;
}

string cam2(string ZO,string Z){
    int X=0;
    int Y=0;
    for (int i=0;i<4;i++){
        if (ZO[i]==48){
            X=X+1;
        }
        else {
            Y=Y+1;
        }
    }
    if (X>Y){
        for (int j=1;j<4;j=j+2){
            if (Z[j]==48){
                Z[j]=49;
            }
            else {
                Z[j]=48;
            }
        }
    }
    else if (X<Y){
        for (int j=2;j<4;j=j+3){
            if (Z[j]==48){
                Z[j]=49;
            }
            else {
                Z[j]=48;
            }
        }
    }
    else {
        Z = camN(Z);
    }
    return Z;
}

string codificacion1(int X,string H,int L){
    string newH="";
    string TNZ="";
    string Z="";
    string newZ="";
    for (int i=0;i<L;i=i+X){
        Z=H.substr(i,X);
        newH = newH + Z;
        if (i<X){
            newZ = camN(Z);
        }
        else {
            string ZO = H.substr(i-X,X);
            newZ = cam2(ZO,Z);
        }
        TNZ = TNZ + newZ;
    }
    /*ifstream fin;
    ofstream fout;
    fout.open("archivocodificado.txt","w");
    fout<<TNZ;*/

    cout<<"  H:"<<newH<<"\n";
    cout<<"TNZ:"<<TNZ<<"\n";
    decimal(TNZ);
    return TNZ;
}

string codificacion2(int X,string H,int L){
    string newH="";
    string TNZ="";
    string Z="";
    string newZ="";
    for (int i=0;i<X;i++){
        newZ=newZ+"0";
    }
    string copiZ ="";
    for (int i=0;i<L;i=i+X){
        Z=H.substr(i,X);
        newH = newH + Z;
        for (int i=0;i<X;i++) {
            if (i==0){
                newZ[i]=Z[i+3];
            }
            else {
                newZ[i]=Z[i-1];
            }
        }
        TNZ=TNZ+newZ;
    }
    /*ifstream fin;
    ofstream fout;
    fout.open("archivocodificado.txt","w");
    fout<<TNZ;*/



    cout<<"  H:"<<newH<<"\n";
    cout<<"TNZ:"<<TNZ<<"\n";
    decimal(TNZ);

    return TNZ;
}











