#include <iostream>
#include "prac_3.h"
#include <fstream>
#include <sstream>
#include <bitset>
#include <string>

using namespace std;



int main(){

    //lectuescri();
    ifstream fin;
    ofstream fout;

    fin.open("prac3.txt");
    char str[5];
    fin.getline(str,5);
    //int X=str.size();
    fin.close();
    int X;
    int Y;
    int Z;
    cout<<"Ingrese 1 si desea codificar o 2 si desea decodificar: ";
    cin>>Z;

    string H="";
    string M;
    H = binario(4,str);
    int L=H.size();



    if (Z==1){
        cout<<"Ingrese un numero par, el cual sera la semilla: ";
        cin>>X;
        cout<<"Ingrese el metodo de codificacion: ";
        cin>>Y;

        if (Y==1){
            M=codificacion1(X,H,L);
        }
        if (Y==2){
            M=codificacion2(X,H,L);
        }
    }




    if (Z==2){
        cout<<"Ingrese un numero par, el cual sera la semilla: ";
        cin>>X;
        cout<<"Ingrese el metodo de decodificacion: ";
        cin>>Y;

        ifstream fin;
        ofstream fout;

        fin.open("documento.txt");
        int Q=4+16;
        char str[Q];
        fin.getline(str,Q);
        fin.close();
        if (Y==1){

        }

        if (Y==2){
            int T=X-1;
            for (int i=0;i<T;i++){
                codificacion2(X,str,L);
            }
        }

    }


    cout<<str<<endl;
    return 0;
}
