#ifndef PRAC_3_H

#define PRAC_3_H
#include <string>
using namespace std;

string archivo(string P);

void escribir(string R);

char guardar(char texto[]);

string camN(string Z);

string cam2(string ZO,string Z);

string binario(int X,string str);

string reverse(string s);

string codificacion1(int X,string H,int L);

string codificacion2(int X,string H,int L);

string decimal(string binario);

#endif PRAC_3_H
